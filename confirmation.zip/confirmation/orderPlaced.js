document.addEventListener('DOMContentLoaded', () => {
    const goHomeBtn = document.getElementById('goHomeBtn');

    goHomeBtn.addEventListener('click', () => {
        window.location.href = '/index.html'; // Adjust the URL to your homepage
    });
});
